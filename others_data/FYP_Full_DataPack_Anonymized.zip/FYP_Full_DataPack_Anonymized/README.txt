FYP Full Data Pack (Sales + HR + Docs + Images) — ANONYMIZED (Option 3)
================================================

This pack includes:
1) docs/   : unstructured documents for RAG (sample, anonymized)
2) images/ : sample table screenshots and charts for visual input demo (generated from anonymized data)
3) ground_truth/ : CSV outputs used as ground truth to verify answers

Sales dataset source: retail_sales_anonymized.csv
HR dataset source: HR_anonymized.csv

Generated months:
- Latest sales month: 2024-06
- Previous sales month: 2024-05

Suggested demo questions:
- "sales bulan ni berapa?"
- "banding sales bulan ni vs bulan lepas"
- "top 3 product bulan 2024-06"
- Upload images/sales_region_kpi_2024-06.png and ask: "summarize table ini"
- "how many employees work in the Department_?? ?" (use department label from HR table)
- Upload images/hr_attrition_by_agegroup.png and ask: "which age group has highest attrition?"

Notes:
- Product, region, and employee identifiers are anonymized (e.g., Product_01, Region_01, SalesRep_01).
- HR categorical fields (Department, JobRole, etc.) are anonymized for consistency and confidentiality.
- Table images are generated from ground_truth CSV files in this pack.
